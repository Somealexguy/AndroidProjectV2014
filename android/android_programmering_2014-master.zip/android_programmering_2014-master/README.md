Android-Programmering 2014
==========================

Eksempler til kurset i Android-Programmering 2014 ved Høgskolen i Østfold

## Lecture 02 - 14.01.2013
* Activity
* Eksplisitte Intents
* Intent Filter
* Implisitte Intents
  * Action
    * Extras
  * Category
  * Data

## Lecture 01 - 07.01.2013
* Hva er Android?
* Historie
* Versjoner
* Androidarkitekturen
* Activity life cycle
* Oppsett utviklingsmiljø
