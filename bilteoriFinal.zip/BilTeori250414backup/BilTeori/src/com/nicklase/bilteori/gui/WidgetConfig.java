package com.nicklase.bilteori.gui;

import com.nicklase.bilteori.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class WidgetConfig extends Activity implements OnClickListener{


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.widgetconfig);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

}
