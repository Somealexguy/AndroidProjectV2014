package com.nicklase.bilteori.logic;

import android.R;
import android.app.Application;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.widget.CheckBox;

public class CheckboxChecked extends Application{
	
	public static int firstTime = 1;

	public void onCreate()
	{	super.onCreate();
	
	}

}
