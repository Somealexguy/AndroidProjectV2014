package com.nicklase.bilteori.logic;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;

public class SendEmail {
	
	
	
	public void skrivMelding(View v){
	
		
		Log.w("test", "mail");
		
/*		String tilEmail = "test@mail.com";
		//findViewById(R.id.);
		
		
		Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
			"mailto", tilEmail, null));

		emailIntent.setType("message/rfc822");
		emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
		emailIntent.putExtra(Intent.EXTRA_TEXT, "Hei, jeg anbefaler deg teoriappen! Stikk og last den ned da vel! Link: www.apple.no");
		
		
		startActivity(Intent.createChooser(emailIntent, "Send Email..."));
	
}

	private void startActivity(Intent createChooser) {
		// TODO Auto-generated method stub
*/		
	}
}
