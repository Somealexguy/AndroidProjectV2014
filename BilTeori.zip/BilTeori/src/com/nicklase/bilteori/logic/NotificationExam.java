package com.nicklase.bilteori.logic;
//not in use yet
public class NotificationExam {

}
