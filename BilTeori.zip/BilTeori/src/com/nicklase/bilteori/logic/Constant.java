package com.nicklase.bilteori.logic;

public class Constant {
	public static final String WRITE_ERROR="writeError";
	public static final String WRITE_STATISTICS="writeStatistics";
}
