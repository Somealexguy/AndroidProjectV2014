package com.nicklase.bilteori.logic;

import java.io.File;

//not in use yet
public class FileReader {

	
		
	
		/// <summary>
		///   Reads the result of an exam walkthrough.
		/// </summary>
		// not in use yet.
		public void readStatistics(){
			String path="stats.txt";
			File file= new File(path);
			try {
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
}

	