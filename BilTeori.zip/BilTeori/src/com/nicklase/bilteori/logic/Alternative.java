package com.nicklase.bilteori.logic;

public class Alternative {
//not in use yet
}
